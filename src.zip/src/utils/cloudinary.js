import { v2 as cloudinary } from "cloudinary"
import fs from "fs"
import ApiError from "./ApiError.js";

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET // Click 'View API Keys' above to copy your API secret
});

const uploadOnCloudinary = async (localFilePath) => {
    try {
        if (!localFilePath) return null;
        //upload the file on cloudinary
        const response = await cloudinary.uploader.upload
            (localFilePath, {
                resource_type: "auto"
            }
            )
        //file has been uploaded successfully
        fs.unlinkSync(localFilePath)//removing the locally saved temp file as the upload operation got failed
        return response;
    }
    catch (error) {
        fs.unlinkSync(localFilePath)//removing the locally saved temp file as the upload operation got failed
        return null
    }
}

const deleteFromCloudinary = async (publicId, options) => {
    try {
       const response=  await cloudinary.uploader.destroy(publicId,options);
       response.result="successfully deleted from cloudinary also";
       return response;
    }
    catch(error) {
         throw new ApiError(500,error) ;
    }
}
export  {uploadOnCloudinary,deleteFromCloudinary}

// cloudinary.v2.uploader.upload(
//     "https://upload.wikimedia.org/wikipedia/commons/a/ae/Olympic_flag.jpg",
//     { public_id: "olympic_flag" },
//     function(error, result) {
//         console.log(result);
//     }
// );
